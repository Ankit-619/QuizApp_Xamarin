﻿using System;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;


namespace Main_QuizApp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class QuizPage : ContentPage
    {
        private string CorrectAnswer; // Store the correct answer for the current question
        private int score = 0; // Counter for correct answers
        private int questionsAnswered = 0; // Counter for questions answered
        private const int MaxQuestions = 25; // Maximum number of questions
        private const int QuestionTimeLimit = 30; // Time limit for each question (in seconds)
        private int timeLeft; // Remaining time for the current question
        private bool isTimerRunning; // Flag to check if the timer is running
        private int Highscore = 0;
        SqlConnection sqlConnection;
        public string User_name { get; set; }

        public QuizPage(string username)
        {
            InitializeComponent();
            sqlConnection = new SqlConnection("Data Source=192.168.56.1\\MSSQLSERVER,1433;Initial Catalog=QuizAppDB;User ID=Admin;Password=Admin123$;");
            ScoreLabel.Text = "Score: 0"; // Initialize the score label
            LoadQuizQuestions(); // Load the first question
            NavigationPage.SetHasBackButton(this, false); // Hide Back Button
            User_name = username;
            BindingContext = this;
            Title = $"Welcome {User_name}";
            
        }



        

         
        private async Task LoadQuizQuestions()
        {
            try
            {
                sqlConnection.Open();
                string query = "SELECT TOP 1 Question, Option1, Option2, Option3, Option4, CorrectAnswer FROM Quiz ORDER BY NEWID()"; // Fetch a random question
                using (SqlCommand command = new SqlCommand(query, sqlConnection))
                {
                    using (SqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (reader.Read())
                        {
                            // Update the UI with the question and options
                            QuestionLabel.Text = reader["Question"].ToString();
                            Option1Button.Text = reader["Option1"].ToString();
                            Option2Button.Text = reader["Option2"].ToString();
                            Option3Button.Text = reader["Option3"].ToString();
                            Option4Button.Text = reader["Option4"].ToString();

                            // Store the correct answer
                            CorrectAnswer = reader["CorrectAnswer"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
            finally
            {
                sqlConnection.Close();
            }

            // Start the timer for the new question
            StartTimer();
        }

        private void StartTimer()
        {
            timeLeft = QuestionTimeLimit; // Reset the timer
            TimerLabel.Text = $"Time Left: {timeLeft}"; // Update the timer label
            isTimerRunning = true; // Start the timer

            // Start a countdown timer
            Device.StartTimer(TimeSpan.FromSeconds(1), () =>
            {
                if (!isTimerRunning)
                {
                    return false; // Stop the timer if it's not running
                }

                timeLeft--; // Decrement the time left
                TimerLabel.Text = $"Time Left: {timeLeft}"; // Update the timer label

                if (timeLeft <= 0)
                {
                    // Time's up! Skip the question
                    isTimerRunning = false; // Stop the timer
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        await DisplayAlert("Time's Up!", "You ran out of time for this question.", "OK");
                        await SkipQuestion(); // Skip the question
                    });
                    return false; // Stop the timer
                }

                return true; // Continue the timer
            });
        }

        private async Task SkipQuestion()
        {
            // Increment the number of questions answered
            questionsAnswered++;

            // Check if the quiz should end
            if (questionsAnswered >= MaxQuestions)
            {
                // End the quiz and show the final score
                await DisplayAlert("Quiz Finished", $"Your final score is {score}/{MaxQuestions}", "OK");

                // Reset the quiz
                score = 0;
                questionsAnswered = 0;
                ScoreLabel.Text = "Score: 0";
            }

            // Load the next question
            await LoadQuizQuestions();
        }

        private async void OnOptionClicked(object sender, EventArgs e)
        {
            // Stop the timer when an option is clicked
            isTimerRunning = false;
            

            // Handle button click events here
            var button = (Button)sender; // Get the clicked button
            string selectedAnswer = button.Text; // Get the text of the clicked button

            // Check if the selected answer is correct
            if (selectedAnswer == CorrectAnswer)
            {
                score++; // Increment the score
                await DisplayAlert("Result", "Correct!", "OK");
            }
            else
            {
                await DisplayAlert("Result", "Incorrect!", "OK");
            }

            // Update the score label
            ScoreLabel.Text = $"Score: {score}";

           




            // Increment the number of questions answered
            questionsAnswered++;

            // Check if the quiz should end
            if (questionsAnswered >= MaxQuestions)
            {
                // End the quiz and show the final score
                await DisplayAlert("Quiz Finished", $"Your final score is {score}/{MaxQuestions}", "OK");

                if (Highscore < score)
                { HighestScoreLabel.Text = $"High Score : {score}"; }

                // Reset the quiz
                score = 0;
                questionsAnswered = 0;
                ScoreLabel.Text = "Score: 0";
                
            }

            // Load the next question
            await LoadQuizQuestions();
        }

        private void onclick(object sender, EventArgs e)
        {
            var button = (Button)sender;
            button.BackgroundColor = Color.Black;
            button.TextColor = Color.White;
        }

        private void onrelease(object sender, EventArgs e)
        {
            var button = (Button)sender;
            button.BackgroundColor = Color.White;
            button.TextColor = Color.Black;
        }

        private async void OnLogoutClicked(object sender, System.EventArgs e)
        {
            bool confirm = await DisplayAlert("Logout", "Are you sure you want to logout?", "Yes", "No");
            if (confirm)
            {
                Application.Current.MainPage = new NavigationPage(new LoginPage()); // Go to Login Page
            }
        }
    }
}