﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Main_QuizApp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AdminUserPage : ContentPage
    {

        public class User
        {
            public int ID { get; set; }
            public string Username { get; set; }
            public string Password { get; set; }
            public string Email { get; set; }
            public string DateOfBirth { get; set; }
        }

        SqlConnection sqlConnection;

        public AdminUserPage()
        {
            InitializeComponent();
            sqlConnection = new SqlConnection("Data Source=192.168.56.1\\MSSQLSERVER,1433;Initial Catalog=QuizAppDB;User ID=Admin;Password=Admin123$;");
        }

        private async void Insert_Clicked(object sender, EventArgs e)
        {
            try
            {
                sqlConnection.Open();
                string query = "INSERT INTO dbo.[Users] (Username, Password, Email, DateOfBirth) " +
                               "VALUES (@Username, @Password, @Email, @DateOfBirth)";
                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                   
                    cmd.Parameters.AddWithValue("@Username", UsernameText.Text);
                    cmd.Parameters.AddWithValue("@Password", PasswordText.Text);
                    cmd.Parameters.AddWithValue("@Email", EmailText.Text);
                    cmd.Parameters.AddWithValue("@DateOfBirth", DateOfBirthText.Text);
                    cmd.ExecuteNonQuery();
                }
                sqlConnection.Close();
                await DisplayAlert("Success", "User added successfully!", "OK");
                ClearFields();
                Retrieve_Clicked(sender, e); // Refresh the list
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void Update_Clicked(object sender, EventArgs e)
        {
            try
            {
                sqlConnection.Open();
                string query = "UPDATE dbo.Users SET Username = @Username, Password = @Password, " +
                               "Email = @Email, DateOfBirth = @DateOfBirth WHERE ID = @ID";
                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(IDText.Text));
                    cmd.Parameters.AddWithValue("@Username", UsernameText.Text);
                    cmd.Parameters.AddWithValue("@Password", PasswordText.Text);
                    cmd.Parameters.AddWithValue("@Email", EmailText.Text);
                    cmd.Parameters.AddWithValue("@DateOfBirth", DateOfBirthText.Text);
                    cmd.ExecuteNonQuery();
                }
                sqlConnection.Close();
                await DisplayAlert("Success", "User updated successfully!", "OK");
                ClearFields();
                Retrieve_Clicked(sender, e); // Refresh the list
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void Delete_Clicked(object sender, EventArgs e)
        {
            try
            {
                sqlConnection.Open();
                string query = "DELETE FROM dbo.Users WHERE ID = @ID";
                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(IDText.Text));
                    cmd.ExecuteNonQuery();
                }
                sqlConnection.Close();
                await DisplayAlert("Success", "User deleted successfully!", "OK");
                ClearFields();
                Retrieve_Clicked(sender, e); // Refresh the list
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void Retrieve_Clicked(object sender, EventArgs e)
        {
            try
            {
                sqlConnection.Open();
                string query = "SELECT * FROM dbo.Users";
                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        List<User> users = new List<User>();
                        while (reader.Read())
                        {
                            users.Add(new User
                            {
                                ID = Convert.ToInt32(reader["ID"]),
                                Username = reader["Username"].ToString(),
                                Password = reader["Password"].ToString(),
                                Email = reader["Email"].ToString(),
                                DateOfBirth = reader["DateOfBirth"].ToString()
                            });
                        }
                        MyListView.ItemsSource = users;
                    }
                }
                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void DeleteAll_Clicked(object sender, EventArgs e)
        {
            try
            {
                sqlConnection.Open();
                string query = "DELETE FROM dbo.Users"; // Deletes all records from Users table
                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    cmd.ExecuteNonQuery(); // Executes the delete query
                }
                sqlConnection.Close();
                await DisplayAlert("Success", "All user records have been deleted.", "OK");
                MyListView.ItemsSource = null; // Clears the ListView after deletion
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private void ClearFields()
        {
            IDText.Text = "";
            UsernameText.Text = "";
            PasswordText.Text = "";
            EmailText.Text = "";
            DateOfBirthText.Text = "";
        }
    }
}