﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Main_QuizApp;

namespace Main_QuizApp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AdminPage : ContentPage
    {




       

        public AdminPage()
        {
            InitializeComponent();


        }

        private async void UserPage(object sender, EventArgs e)
        {
            Navigation.PushAsync(new AdminUserPage());
        }

        private async void QuizPage(object sender, EventArgs e)
        {
            Navigation.PushAsync(new AdminQuizPage());

        }

        
             private async void OnLogoutClicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new AdminLogin());
        }




    }
}