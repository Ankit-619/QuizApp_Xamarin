﻿using System;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using Main_QuizApp;

namespace Main_QuizApp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class LoginPage : ContentPage
    {
        SqlConnection sqlConnection;

        public LoginPage()
        {
            InitializeComponent();
            sqlConnection = new SqlConnection("Data Source=192.168.56.1\\MSSQLSERVER,1433;Initial Catalog=QuizAppDB;User ID=Admin;Password=Admin123$;");
        }

        private async void OnLoginClicked(object sender, EventArgs e)
        {
            string username = UsernameEntry.Text;
            string password = PasswordEntry.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                await DisplayAlert("Error", "Please enter both username and password.", "OK");
                return;
            }

            try
            {
                sqlConnection.Open();
                string query = "SELECT COUNT(*) FROM dbo.[Users] WHERE Username = @Username AND Password = @Password";
                using (SqlCommand command = new SqlCommand(query, sqlConnection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        await DisplayAlert("Success", "Login successful!", "OK");
                        await Navigation.PushAsync(new QuizPage(username)); // Navigate to the main page
                    }
                    else
                    {
                        await DisplayAlert("Error", "Invalid username or password.", "OK");
                    }
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        private async void OnRegisterClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new RegisterPage()); // Navigate to the registration page
        }

        private void AdminButton_Clicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new AdminLogin());
        }

        private void ForgotPassword(object sender, EventArgs e)
        {
            Navigation.PushAsync(new UserReset());
        }
    }
}