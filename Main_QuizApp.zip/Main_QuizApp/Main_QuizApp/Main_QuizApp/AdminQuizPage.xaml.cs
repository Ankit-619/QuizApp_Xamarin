﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Main_QuizApp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AdminQuizPage : ContentPage
    {

        public class QuizQuestion
        {
            public int ID { get; set; }
            public string Question { get; set; }
            public string Option1 { get; set; }
            public string Option2 { get; set; }
            public string Option3 { get; set; }
            public string Option4 { get; set; }
            public string CorrectAnswer { get; set; }
        }

        SqlConnection sqlConnection;
        public AdminQuizPage()
        {
            InitializeComponent();
            sqlConnection = new SqlConnection("Data Source=192.168.56.1\\MSSQLSERVER,1433;Initial Catalog=QuizAppDB;User ID=Admin;Password=Admin123$;");
        }

        private async void CheckConnection_Clicked(object sender, EventArgs e)
        {
            try
            {
                sqlConnection.Open();
                await DisplayAlert("Success", "Connected to the database!", "OK");
                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void Insert_Clicked(object sender, EventArgs e)
        {
            try
            {
                sqlConnection.Open();
                string query = "INSERT INTO dbo.[Quiz] (Question, Option1, Option2, Option3, Option4, CorrectAnswer) " +
                               "VALUES (@Question, @Option1, @Option2, @Option3, @Option4, @CorrectAnswer)";
                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                   
                    cmd.Parameters.AddWithValue("@Question", QuestionText.Text);
                    cmd.Parameters.AddWithValue("@Option1", Option1Text.Text);
                    cmd.Parameters.AddWithValue("@Option2", Option2Text.Text);
                    cmd.Parameters.AddWithValue("@Option3", Option3Text.Text);
                    cmd.Parameters.AddWithValue("@Option4", Option4Text.Text);
                    cmd.Parameters.AddWithValue("@CorrectAnswer", CorrectAnswerText.Text);
                    cmd.ExecuteNonQuery();
                }
                sqlConnection.Close();
                await DisplayAlert("Success", "Question added successfully!", "OK");
                ClearFields();
                Retrieve_Clicked(sender, e); // Refresh the list
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void Update_Clicked(object sender, EventArgs e)
        {
            try
            {
                sqlConnection.Open();
                string query = "UPDATE dbo.Quiz SET Question = @Question, Option1 = @Option1, Option2 = @Option2, " +
                               "Option3 = @Option3, Option4 = @Option4, CorrectAnswer = @CorrectAnswer WHERE ID = @ID";
                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@QuizId", Convert.ToInt32(IDText.Text));
                    cmd.Parameters.AddWithValue("@Question", QuestionText.Text);
                    cmd.Parameters.AddWithValue("@Option1", Option1Text.Text);
                    cmd.Parameters.AddWithValue("@Option2", Option2Text.Text);
                    cmd.Parameters.AddWithValue("@Option3", Option3Text.Text);
                    cmd.Parameters.AddWithValue("@Option4", Option4Text.Text);
                    cmd.Parameters.AddWithValue("@CorrectAnswer", CorrectAnswerText.Text);
                    cmd.ExecuteNonQuery();
                }
                sqlConnection.Close();
                await DisplayAlert("Success", "Question updated successfully!", "OK");
                ClearFields();
                Retrieve_Clicked(sender, e); // Refresh the list
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void Delete_Clicked(object sender, EventArgs e)
        {
            try
            {
                sqlConnection.Open();
                string query = "DELETE FROM dbo.Quiz WHERE ID = @ID";
                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@ID", Convert.ToInt32(IDText.Text));
                    cmd.ExecuteNonQuery();
                }
                sqlConnection.Close();
                await DisplayAlert("Success", "Question deleted successfully!", "OK");
                ClearFields();
                Retrieve_Clicked(sender, e); // Refresh the list
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void Retrieve_Clicked(object sender, EventArgs e)
        {
            try
            {
                sqlConnection.Open();
                string query = "SELECT * FROM dbo.Quiz";
                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        List<QuizQuestion> quizQuestions = new List<QuizQuestion>();
                        while (reader.Read())
                        {
                            quizQuestions.Add(new QuizQuestion
                            {
                                ID = Convert.ToInt32(reader["QuizId"]),
                                Question = reader["Question"].ToString(),
                                Option1 = reader["Option1"].ToString(),
                                Option2 = reader["Option2"].ToString(),
                                Option3 = reader["Option3"].ToString(),
                                Option4 = reader["Option4"].ToString(),
                                CorrectAnswer = reader["CorrectAnswer"].ToString()
                            });
                        }
                        MyListView.ItemsSource = quizQuestions;
                    }
                }
                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        private async void DeleteAll_Clicked(object sender, EventArgs e)
        {
            try
            {
                sqlConnection.Open();
                string query = "DELETE FROM dbo.Quiz"; // Deletes all records from Quiz table

                using (SqlCommand cmd = new SqlCommand(query, sqlConnection))
                {
                    cmd.ExecuteNonQuery(); // Executes the delete query
                }

                sqlConnection.Close();
                await DisplayAlert("Success", "All quiz records have been deleted.", "OK");

                MyListView.ItemsSource = null; // Clears the ListView after deletion
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }


        private void ClearFields()
        {
            IDText.Text = "";
            QuestionText.Text = "";
            Option1Text.Text = "";
            Option2Text.Text = "";
            Option3Text.Text = "";
            Option4Text.Text = "";
            CorrectAnswerText.Text = "";
        }
    }
}