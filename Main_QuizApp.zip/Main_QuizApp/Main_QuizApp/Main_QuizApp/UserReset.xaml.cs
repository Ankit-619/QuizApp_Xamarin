﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Main_QuizApp
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class UserReset : ContentPage
	{

		SqlConnection sqlConnection;
		public UserReset()
		{
			InitializeComponent();
			sqlConnection = new SqlConnection("Data Source=192.168.56.1\\MSSQLSERVER,1433;Initial Catalog=QuizAppDB;User ID=Admin;Password=Admin123$;");
		}

        private async void OnResetPasswordClicked(object sender, EventArgs e)
        {
            string email = EmailEntry.Text;
            DateTime dateOfBirth = DateOfBirthPicker.Date;
            string newPassword = NewPasswordEntry.Text;

            // Validate inputs
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(newPassword))
            {
                await DisplayAlert("Error", "Please fill in all fields.", "OK");
                return;
            }

            try
            {
                sqlConnection.Open();

                // Step 1: Verify email and date of birth
                string verifyQuery = "SELECT COUNT(*) FROM dbo.[Users] WHERE Email = @Email AND DateOfBirth = @DateOfBirth";
                using (SqlCommand verifyCmd = new SqlCommand(verifyQuery, sqlConnection))
                {
                    verifyCmd.Parameters.AddWithValue("@Email", email);
                    verifyCmd.Parameters.AddWithValue("@DateOfBirth", dateOfBirth.ToString("yyyy-MM-dd"));

                    int count = (int)verifyCmd.ExecuteScalar();

                    if (count == 0)
                    {
                        await DisplayAlert("Error", "Invalid email or date of birth.", "OK");
                        return;
                    }
                }

                // Step 2: Update the password
                string updateQuery = "UPDATE dbo.[Users] SET Password = @Password WHERE Email = @Email";
                using (SqlCommand updateCmd = new SqlCommand(updateQuery, sqlConnection))
                {
                    updateCmd.Parameters.AddWithValue("@Password", newPassword);
                    updateCmd.Parameters.AddWithValue("@Email", email);
                    updateCmd.ExecuteNonQuery();
                }

                sqlConnection.Close();
                await DisplayAlert("Success", "Password reset successfully!", "OK");
                await Navigation.PopAsync(); // Go back to the previous page
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
            finally
            {
                if (sqlConnection.State == System.Data.ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
        }
        }
    }