﻿using System;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Main_QuizApp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class RegisterPage : ContentPage
    {
        SqlConnection sqlConnection;

        public RegisterPage()
        {
            InitializeComponent();
            sqlConnection = new SqlConnection("Data Source=192.168.56.1\\MSSQLSERVER,1433;Initial Catalog=QuizAppDB;User ID=Admin;Password=Admin123$;");
        }

        private async void OnRegisterClicked(object sender, EventArgs e)
        {
            string username = UsernameEntry.Text;
            string password = PasswordEntry.Text;
            string confirmPassword = ConfirmPasswordEntry.Text;
            string email = EmailEntry.Text;
            DateTime dateOfBirth = DateOfBirthPicker.Date;

            // Validate inputs
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(email))
            {
                await DisplayAlert("Error", "Please fill in all fields.", "OK");
                return;
            }

            if (password != confirmPassword)
            {
                await DisplayAlert("Error", "Passwords do not match.", "OK");
                return;
            }

            if (!IsValidEmail(email))
            {
                await DisplayAlert("Error", "Invalid email format.", "OK");
                return;
            }

            if (dateOfBirth > DateTime.Today)
            {
                await DisplayAlert("Error", "Date of birth cannot be in the future.", "OK");
                return;
            }

            try
            {
                sqlConnection.Open();
                using (SqlCommand cmd = new SqlCommand("INSERT INTO dbo.[Users] (Username, Password, Email, DateOfBirth) VALUES (@Username, @Password, @Email, @DateOfBirth)", sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@DateOfBirth", dateOfBirth.ToString("yyyy-MM-dd")); // Format as SQL DATE
                    cmd.ExecuteNonQuery();
                }
                sqlConnection.Close();
                await DisplayAlert("Success", "Registration successful!", "OK");
                await Navigation.PushAsync(new LoginPage());
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
        }

        // Validate email format using regex
        private bool IsValidEmail(string email)
        {
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$"; // Simple email regex
            return Regex.IsMatch(email, emailPattern);
        }
    }
}