﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Main_QuizApp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AdminLogin : ContentPage
    {

        SqlConnection sqlConnection;
        public AdminLogin()
        {
            InitializeComponent();

            sqlConnection = new SqlConnection("Data Source=192.168.56.1\\MSSQLSERVER,1433;Initial Catalog=QuizAppDB;User ID=Admin;Password=Admin123$;");
        }

        private async void OnLoginClicked(object sender, EventArgs e)
        {
            string Name = UsernameEntry.Text;
            string password = PasswordEntry.Text;

            if (string.IsNullOrEmpty(Name) || string.IsNullOrEmpty(password))
            {
                await DisplayAlert("Error", "Please enter both username and password.", "OK");
                return;
            }

            try
            {
                sqlConnection.Open();
                string query = "SELECT COUNT(*) FROM dbo.[AdminTable] WHERE Name = @Name AND Password = @Password";
                using (SqlCommand command = new SqlCommand(query, sqlConnection))
                {
                    command.Parameters.AddWithValue("@Name", Name);
                    command.Parameters.AddWithValue("@Password", password);

                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        await DisplayAlert("Success", "Login successful!", "OK");
                        await Navigation.PushAsync(new AdminPage()); // Navigate to the main page
                    }
                    else
                    {
                        await DisplayAlert("Error", "Invalid username or password.", "OK");
                    }
                }
            }
            catch (Exception ex)
            {
                await DisplayAlert("Error", ex.Message, "OK");
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        private async void Back_clicked(object sender, EventArgs e)
        { 
            await Navigation.PushAsync(new LoginPage());
        }
    }
}